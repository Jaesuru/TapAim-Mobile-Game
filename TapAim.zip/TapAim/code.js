var points = 0;
var lives = 3;

onEvent("beginButton", "click", function( ) {
  setScreen("introduction");
  playSound("assets/category_app/arcade_game_button_tap.mp3");
});

onEvent("startButton", "click", function( ) {
  setScreen("gameScreen");
  playSound("assets/category_app/arcade_game_button_tap.mp3");
});

function pointUpdate() {
  points = points + 1;
  setText("total_points", points);
  playSound("assets/category_app/app_interface_click.mp3");
}
function summaryUpdate() {
  setScreen("summaryScreenWin");
  setText("livesRemaining", lives);
  playSound("assets/category_achievements/lighthearted_bonus_objective_2.mp3");
}
function gameFunction() {
  setPosition("bullseye", randomNumber(50, 250), randomNumber(50, 300));
  setSize("bullseye", randomNumber(10, 200), randomNumber(15, 150));
  playSound("assets/category_app/app_interface_click.mp3", false);
  pointUpdate();
  if (points == 20) {
    summaryUpdate();
  }
}
onEvent("bullseye", "click", function( ) {
  gameFunction();
});

function livesUpdate() {
  lives = lives - 1;
  setText("total_lives", lives);
  playSound("assets/category_collect/collect_item_bling_1.mp3");
}
function summaryUpdateLose() {
  setScreen("summaryScreenLose");
  setText("pointsLose", points);
  playSound("assets/category_alerts/vibrant_game_negative_affirmation.mp3");
}
function gameLose() {
  livesUpdate();
  if (lives == 0) {
    summaryUpdateLose();
  }
}
onEvent("background", "click", function( ) {
  gameLose();
});

function retry() {
  setScreen("homeScreen");
  points = 0;
  lives = 3;
  setText("total_points", points);
  setText("total_lives", lives);
}
onEvent("restartGame", "click", function( ) {
  retry();
});
onEvent("playAgain", "click", function( ) {
  retry();
});
